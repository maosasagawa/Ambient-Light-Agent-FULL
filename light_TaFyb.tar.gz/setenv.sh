#!/usr/bin/env bash

# Fill in your actual secrets before running:
# export AIHUBMIX_API_KEY="..."
# export BFL_API_KEY="..."

export AIHUBMIX_API_KEY="sk-Tz9sdL08tvzJr96I3fE1Ed97C15346B6B9B3Df5dFa978939"
export BFL_API_KEY="bfl_PC5jPFNwzjKGJahVF8onTxMhblguMY6v"

# Optional defaults
export MATRIX_IMAGE_MODEL="flux-2-flex"
export FLUX_POLL_INTERVAL_S="0.25"
export FLUX_POLL_MAX_SECONDS="20"
export STRIP_KB_FILE="strip_kb.txt"
export MAX_UPLOAD_MB="10"
export MAX_IMAGE_PIXELS="10000000"
export MQTT_ENABLED="false"
export MQTT_HOST="localhost"
export MQTT_PORT="1883"
export MQTT_TOPIC="ambient-light/events"
